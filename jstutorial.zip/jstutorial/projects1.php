<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JavaScript Projects</title>
</head>
<style>
    /* Basic reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Body styling */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    text-align: center;
    padding: 50px 0;
}

/* Heading styles */
h3 {
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
}

h2 {
    font-size: 28px;
    color: #333;
    margin-top: 20px;
}

/* Span text styling */
span {
    font-size: 18px;
    color: #333;
    display: block;
    margin-top: 10px;
}

/* Button styles */
.button {
    display: inline-block;
    width: 60px;
    height: 60px;
    margin: 10px;
    border-radius: 50%;
    cursor: pointer;
    transition: transform 0.2s ease;
}

.button:hover {
    transform: scale(1.1);
}

#grey {
    background-color: grey;
}

#white {
    background-color: white;
    border: 1px solid #ddd;
}

#blue {
    background-color: blue;
}

#yellow {
    background-color: yellow;
}

#red {
    background-color: red;
}

</style>
<body>
    <h3>Colour Changer Projects</h3>
    <span class="button" id="grey"></span>
    <span class="button" id="white"></span>
    <span class="button" id="blue"></span>
    <span class="button" id="yellow"></span>
    <span class="button" id="red"></span>
    <h2>Try Clicking on One of the Colours above</h2>
    <span>To Change the BackgroundColor of this Page</span>
    <script src="projects1.js"></script>
</body>
</html>