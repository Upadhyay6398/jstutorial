<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Circle Watch Time Zone</title>
  <link rel="stylesheet" href="styles.css">
</head>
<style>
    body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
  background-color: #f4f4f4;
}

.clock-container {
  text-align: center;
}

.clock {
  position: relative;
  width: 300px;
  height: 300px;
  border-radius: 50%;
  border: 5px solid #333;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 20px;
}

.hour-hand, .minute-hand, .second-hand {
  position: absolute;
  bottom: 50%;
  width: 2px;
  background-color: #333;
  transform-origin: bottom;
  transform: rotate(0deg);
}

.hour-hand {
  height: 60px;
  width: 6px;
  background-color: #000;
}

.minute-hand {
  height: 80px;
  background-color: #666;
}

.second-hand {
  height: 90px;
  background-color: red;
}

.center-dot {
  position: absolute;
  width: 20px;
  height: 20px;
  background-color: #333;
  border-radius: 50%;
}

.time-zone, .time {
  font-size: 1.2rem;
}

.time {
  margin-top: 10px;
}

</style>
<body>
  <div class="clock-container">
    <div class="clock">
      <div class="hour-hand"></div>
      <div class="minute-hand"></div>
      <div class="second-hand"></div>
      <div class="center-dot"></div>
    </div>
    <p class="time-zone">Current Time Zone: <span id="time-zone">GMT</span></p>
    <div class="time">Time: <span id="time">00:00:00</span></div>
  </div>

  <script src="projects4.js"></script>
</body>
</html>
