<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Change Event Example</title>
</head>
<body>
  <select id="dropdown">
    <option value="apple">Apple</option>
    <option value="banana">Banana</option>
    <option value="cherry">Cherry</option>
  </select>
  <p id="message"></p>

  <script>
    document.getElementById('dropdown').addEventListener("change",function(){
        document.getElementById('message').innerHTML="Your Change is:"+this.value
    })
  </script>
</body>
</html>
