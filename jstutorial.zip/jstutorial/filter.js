
const myNums=[1,2,3,4,5,6,7,8,9,10]
const newNums=myNums.filter( (num)=>num > 4 )
console.log(newNums)//Output=>[5,6,7,8,9,10]


//Another Way to define the Filter In JavaScript 

const anotherNumber=myNums.filter((num)=>{
    return num>4
})
console.log(anotherNumber);//Output=>[5, 6, 7, 8, 9, 10]
//Note if we are using { } braces then it is must need to use return keyword and if we are using () then there is no need to use return keyword...

// const anotherNewNums=[]
// anotherNewNums.forEach((num)=>{
// if(num>4)
// {
//     anotherNewNums.push(num)
//     console.log(anotherNewNums)
// }
// }) This is the another way to filter wihtout using the filter method....

const books=[
    {
        title:'Book One',
        genre:'fiction',
        publish:1981,
        edition:2004
    },
    {
        title:'Book Two',
        genre:'Non-Fiction',
        publish:1982,
        edition:2008
    },
    {
        title:'Book Three',
        genre:'History',
        publish:1999,
        edition:2007
    },
    {
        title:'Book Four',
        genre:'Non-Fiction',
        publish:1989,
        edition:2010
    },
    {
        title:'Book Five',
        genre:'Science',
        publish:2009,
        edition:2014
    },
    {
        title:'Book Six',
        genre:'Fiction',
        publish:1987,
        edition:2010
    },
    {
        title:'Book Seven',
        genre:'History',
        publish:1986,
        edition:1996
    },
    {
        title:'Book Eight',
        genre:'Science',
        publish:2011,
        edition:2016
    },
    {
        title:'Book Nine',
        genre:'Non Fiction',
        publish:1981,
        edition:1989
    },
]

const userBooks=books.filter((bk)=>bk.genre==='History')
console.log(userBooks)//Output=>{title: 'Book Three', genre: 'History', publish: 1999, edition: 2007}
//{title: 'Book Seven', genre: 'History', publish: 1986, edition: 1996}

const publisBooks=books.filter((publishB)=>publishB.publish>=2000)
console.log(publisBooks); //Output=> {title: 'Book Five', genre: 'Science', publish: 2009, edition: 2014}
//{title: 'Book Eight', genre: 'Science', publish: 2011, edition: 2016}


const newArray=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

const filterArray=newArray.filter((num)=>num<=10)
console.log(filterArray)
//Output=>[1,2,3,4,5,6,7,8,9,10]
