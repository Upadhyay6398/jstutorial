<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Immediately Invoked Function Expression</title>
</head>
<body>
<h3>Immediately Invoked Function Expression</h3>
<script src="iife.js" type="text/javascript"></script>
</body>
</html>