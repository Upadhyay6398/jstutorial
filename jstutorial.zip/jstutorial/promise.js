//Promsie is an Object represtenting eventual completion

const promoseOne=new Promise(function(resolve,reject){

    //Do an Async task
    //DB Calls
    //Cryptography
    //Network Calls
    setTimeout(function(){
        console.log("Async Task is Complete")
        resolve()
    },1000)
})

promoseOne.then(function(){
    console.log("Promise Consumed");
    
})

new Promise(function(resolve,reject){
    setTimeout(function(){
        console.log("Async Second Method Task is complete")
        resolve();
    },1000)
})
.then(function(){
    console.log("Promise Second is complete")
})

const promiseThree=new Promise(function(resolve,reject){

    setTimeout(function(){
resolve({username:"Chai or code",email:"brajmohan@onlinew2i.com"})
    },1000)
})

promiseThree.then(function(user){
console.log(user)
})


const promiseFourth = new Promise(function(resolve, reject) {
    setTimeout(function() {
        let error = false;
        if (!error) {
            resolve({ username: "Braj Mohan Upadhyay", email: "brajmohanupadhyayonlinew2i.com" });
        } else {
            reject('ERROR: Something went wrong');
        }
    }, 1000);
});

promiseFourth
    .then(function(user) {
        console.log(user);  
        return user.username;  
    })
    .then(function(username) {
        console.log(username);  
    })
    .catch(function(error) {
        console.log(error); 
    })
    .finally(function(){
        console.log("Your Promises is Executed Successfully")
    });

    const promiseFive = new Promise(function(resolve, reject) {
        setTimeout(function() {
            let error = false;
            if (!error) {
                resolve({ username: "JavaScript", password: "javascript@123" });
            } else {
                reject('ERROR: Js went wrong');
            }
        }, 1000);
    });
    
    async function consumendFunction() {
        try {
            const response = await promiseFive;
            console.log(response);
        } catch (error) {
            console.log(error); 
        }
    }
    consumendFunction();

    async function getAllUser() {
        try {
            const response = await fetch('https://jsonplaceholder.typicode.com/users');
            console.log(response);
            
            const data = await response.json();
            console.log(data);
        } catch (error) {
            console.log("ERROR", error);
        }
    }
    getAllUser();
    