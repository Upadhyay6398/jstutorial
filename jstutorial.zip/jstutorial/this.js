const jsUser={

    username:"Hitesh",
    price:999,

    weleocomeMessage:function()
    {
        console.log(`${this.username} , Welcome to Website`)
       console.log(`Welcome to ${this.username} and your Couse Price is ${this.price}`) 
    }
    
}

jsUser.weleocomeMessage()//Output=>Hitesh, Welcome to Website
console.log(this)
jsUser.username="Sam"
jsUser.weleocomeMessage(); //Output=>Sam , Welcome to Website

//This are used to refer the current context...
//Browser ke ander Global Object Window Object Hota h

//++++++++++++++++++++++++++++++++++ Arraow function +++++++++++++++++++++++++++++


function chai()
{
    let username="Braj Mohan"
    console.log(this.username)
}
chai() //Ouptput=>Undefined

const chaiorcode=function()
{
    let username="Braj Mohan Upadhyay"
    console.log(this.username)
}
chaiorcode();//Ouput=>Undefined

const codeWithHarry= () =>{

    let username="Braj Mohan Upadhyay"
    console.log(this.username)
}
codeWithHarry();

const addTwoNumbers=(num1,num2)=>{

    return num1+num2
}
console.log(addTwoNumbers(10,20));

const addThreeNumbers=(num1,num2,num3)=>(num1+num2+num3)
console.log(addThreeNumbers(10,20,30));

const value3=((num1,num2)=>num1+num2)
console.log(value3(10,20));//Output=>30