//Chaining in JavaScript....

const myArray=[1,2,3,4,5,6,7,8,9,10];

const newNums=myArray.map((num)=>num*10).map((num1)=>num1+1).filter((num3)=>num3>=40)
console.log(newNums)//Output=>[41, 51, 61, 71, 81, 91, 101]

const chainingArray=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

const newUpdatedArray=chainingArray.map((num)=>num*10).map((num1)=>num1+2).filter((num3)=>num3>=45)
console.log(newUpdatedArray)//Output=> [52, 62, 72, 82, 92, 102, 112, 122, 132, 142, 152, 162, 172, 182, 192, 202]