<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promise In JavaScript</title>
</head>
<body>
    <h1>Promise In JavaScript</h1>
    <p>The Promise object represents the eventual completion (or failure) of an asynchronous operation and its resulting value.</p>
    <h1>A Promise is in one of these states:</h1>
    <p>pending: initial state, neither fulfilled nor rejected.</p>
    <p>fulfilled: meaning that the operation was completed successfully.</p>
    <p>rejected: meaning that the operation failed.</p>
</body>
<script src="promise.js"></script>
</html>