const myFruits=["Apple","Banana","Guavava","Orange","Papaya","Pineapple","Pear"]

const values=myFruits.forEach((item)=>{
    console.log(item)
    return item
})
console.log(values)

//Note:-forEach method in JavaScript does not return any value. It always returns undefined