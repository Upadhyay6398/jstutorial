var config = {
    cUrl: "https://api.countrystatecity.in/v1/countries",
    cKey: "NHhvOEcyWk50N2Vna3VFTE00bFp3MjFKR0ZEOUhkZlg4RTk1MlJlaA=="
}

var countrySelect = document.querySelector('#country');
var stateSelect = document.querySelector('#state');
var selectCity = document.querySelector('#city');

function loadCountries() 
{
    let apiEndPoint = config.cUrl;
    fetch(apiEndPoint, { headers: { "X-CSCAPI-KEY": config.cKey } })
        .then(response => response.json())
        .then(data => { 
            console.log(data)
            data.forEach(country =>
            {
                const option = document.createElement('option');
                option.value = country.iso2;
                option.textContent = country.name;
                countrySelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error Loading Countries', error));
}
function loadStates()
{

    const selectCountryCode = countrySelect.value;
    stateSelect.innerHTML = '<option>Select State</option>'; // Clear existing state options

    fetch(`${config.cUrl}/${selectCountryCode}/states`, { headers: { "X-CSCAPI-KEY": config.cKey } })
        .then(response => response.json())
        .then(data => {
            data.forEach(state => {
                const option = document.createElement('option');
                option.value = state.iso2;
                option.textContent = state.name;
                stateSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error Loading States', error));
}
function loadCities() {

    const selectCountryCode = countrySelect.value;
    const selectStateCode = stateSelect.value;

    selectCity.innerHTML = '<option>Select City</option>'; // Clear existing city options
    fetch(`${config.cUrl}/${selectCountryCode}/states/${selectStateCode}/cities`, { headers: { "X-CSCAPI-KEY": config.cKey } })
        .then(response => response.json())
        .then(data => {
            console.log(data);

            data.forEach(city => {
                const option = document.createElement('option');
                option.value = city.iso2 ||'Unknown';
                option.textContent = city.name;
                selectCity.appendChild(option);
            });
        })
        .catch(error => console.error('Error Loading Cities', error));
}
window.onload = loadCountries;
