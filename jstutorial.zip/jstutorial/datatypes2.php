<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Types</title>
</head>
<body>
    <h1>Data Types of JavaScript</h1>
    <script src="datatypes.js"type="text/javascript"></script>
    <script src="datatypes2.js"type="text/javascript"></script>
</body>
</html>