//Dom In JavaScript
//Dom Stands for Document Object Model It is a program Interface for web documents, which represents the structure of an HTML or XML document as a tree of nodes....

//There are different types of Dom Element like

//If we write this code in console then it will be provide the output...

document.getElementById('title')

//  Output=><h1 class="heading" id="title">Dom Learning on Chai or Code...</h1>

document.getElementById('title').id// Output=>title
document.getElementById('title').class //Output=>undefined Suppose we want to access the calss and we can not access this type because behind the scene document is understand only className
document.getElementById('title').className //Output=>heading
document.getElementById('title').innerHTML="Braj Mohan Upadhyay" //Output=> Dom Learning on Chai or Code...  Braj Mohan Upadhyay Ouput Provide this after if we use innrerHTML...

document.getElementById('title').getAttribute('class')   //Output=>heading 
document.getElementById('title').getAttribute('id')  //Output=>title

document.getElementById('title').style.backgroundColor='red' //it is change the background color red...
document.getElementById('title').style.color="green" //it will change the text color Green...

// Note to get the content from the Html Webpage based upon the id there are three different methods are textContent ,innerHtml,innerText 

document.getElementById('title').textContent //Output=>'Dom Learning on Chai or Code...

document.getElementById('title').innerHTML //Output=>'Dom Learning on Chai or Code...

document.getElementById('title').innerText //Output=>'Dom Learning on Chai or Code...

//Note:-Difference b/w document.getElementById('title').innerText and document.getElementById('title').textContent Suppose we have an html Document then in the Html document only visible text are displayed using the property document.getElementById('title').innerText and Suppose in a Html Webpage some unvisible text are there then if we want to show some unvisible text then we can use document.getElementById('title').textContent


// console.log(document.links[2])  //This is used to get the link of Html Document