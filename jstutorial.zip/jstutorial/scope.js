//Scope in JavaScript...

var c=300

if(true)
{
const a=10;
let b=20
var c=30
}
// console.log(a)
// console.log(b)
console.log(c) //Its value is updated because var are used as a global scope

function one()
{
    const username="Braj Mohan Upadhyay"

    function two()
    {
        const website="YouTube"
        console.log(username)
    }
    // console.log(website)
two()
}
one()

if(true)
{
    const username="Hitesh"
    if(username==="Hitesh")
    {
        const website="YouTube"
        console.log(username+website)
    }
    // console.log(website) It can not be access beacuse there is no scope of website...
}


