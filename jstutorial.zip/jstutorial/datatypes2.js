"use strict";
let score="33"
console.log(typeof score)//Output=>String
let valueNumber=Number(score);
console.log(typeof valueNumber);

//But Suppose the value from the Backend Side is let score="33abc"

let anotherScore="33abc"
console.log(typeof anotherScore);//Output=>String
let secondScore=Number(anotherScore);
console.log(secondScore);//Ouput=>Nan
console.log(typeof secondScore);//Output=>Number


//Conversion

//"33"=>33=>Sting to number easily Convert
//"33abc"=>Nan =>It can not be converted
//true=>1,false=>0


//************************Operations*********************************** */

// console.log(2+2);
// console.log(2-2);
// console.log(2*2);
// console.log(2/2);
// console.log(2%2);

console.log(2+"2"+1);//Ouput=>221
console.log(2+2+"1");//Output=>41
console.log("2"+2+"1");//Outupt=>221
console.log("2"+1+1);//Ouput=>211


//Important Note regarding to the NaN

console.log(typeof NaN)//Output=>Number
console.log(2===2)//Output=>true
console.log(NaN===NaN)//Output=>False
console.log(NaN!==NaN)//Output=>True

//In JavaScript, NaN is not equal to itself, which is why console.log(NaN === NaN) returns false...