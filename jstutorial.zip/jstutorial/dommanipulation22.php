<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dom Manipulation In JavaScript</title>
</head>
<body style="background-color: #212121;color:#ffff">
    <ul class="language">
    <li>JavaScript</li>
    </ul>

<script src="dommanipulation.js"></script>
</body>
</html>