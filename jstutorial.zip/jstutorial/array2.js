
const marvel_heroes=['Thor','Ironmam','Spiderman']
const dc_heroes=['Superman','Flash','Batman'];

marvel_heroes.push(dc_heroes);
console.log(marvel_heroes);//Output=>['Thor', 'Ironmam', 'Spiderman', ['Superman','Flash','Batman']] he is provide the output Array with in Array


//For Access the value of the dc_heroes is 
console.log(marvel_heroes[3][1]);//Output=>Flash

const allHeroes=marvel_heroes.concat(dc_heroes);
console.log(allHeroes);//Output=>['Thor', 'Ironmam', 'Spiderman','Superman','Flash','Batman'] It is Combine Two array in a well defined manner

const all_new_heroes=[...marvel_heroes,...dc_heroes];
console.log(all_new_heroes);////Output=>['Thor', 'Ironmam', 'Spiderman','Superman','Flash','Batman'] this is the another way to combine two or mare array It is known an spread the array spread is provide to combine two or more array...

const another_Array=[1,2,3,[4,5,6],7,[3,2,1,[12,10,14,[19,70,11]]]]
console.log(another_Array);//Output=>[1,2,3,[4,5,6],7,[3,2,1,[12,10,14,[19,70,11]]]]
const real_another_array=another_Array.flat(Infinity);
console.log(real_another_array);//Output=>[1, 2, 3, 4, 5, 6, 7, 3, 2, 1, 12, 10, 14, 19, 70, 11]
//It is used to spread out the array if we have an array with in array

console.log(Array.isArray("Hitesh","Braj Mohan Upadhyay"));//Output=>false boolean Type

console.log(Array.from("Hitesh"));//Output=>['H', 'i', 't', 'e', 's', 'h'] It is convert from Array it can be any String 

let score1=100
let score2=200
let score3=300

console.log(Array.of(score1,score2,score3));//Output=>[100, 200, 300]
