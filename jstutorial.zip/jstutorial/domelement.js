const div=document.createElement('div')
console.log(div)//Output=><div></div>
div.className="main"//Output=><div class="main"></div>
div.id=Math.round(Math.random()*10)+1//Output=></div class="main" id="1.22212121"></div>
div.setAttribute("name","enquiryForm")//Output=><div class="main" id="1.222212121" name="enquiryForm"></div>
div.setAttribute("Placeholder","This is an Div")//Output=><div class="main" id="1.222212121" name="enquiryForm" Placeholder="This is an div"></div>
div.style.backgroundColor="green" //Output=><div class="main" id="1.222212121" name="enquiryForm" Placeholder="This is an div" style="backgroundcolor:green"></div>
div.style.padding="20px"  //Output=><div class="main" id="1.222212121" name="enquiryForm" Placeholder="This is an div" style="backgroundcolor:green;padding:20px"></div>
// div.innerText="Chai or Code"
const addText=document.createTextNode("This is an Javascript Dom Manipulation")//<div class="main" id="1.222212121" name="enquiryForm" Placeholder="This is an div" style="backgroundcolor:green;padding:20px">This is an Javascript Dom Manipulation</div>
div.appendChild(addText)
document.body.append(div) //Show on webpage in Green background text