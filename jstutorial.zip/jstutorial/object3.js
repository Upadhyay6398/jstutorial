
const course={
    couseName:"Js in Hindi",
    coursePrice:"999",
    couseInstructor:"Hitesh Chaudhary"
}

//Note:-Suppose we want to access the courseInstructor then we use course.courseInstructor it is too much time taken the another method to access the courseInstructor is

const {couseInstructor}=course
console.log(couseInstructor)//Output=>Hitesh Chaudhary

//Now for DeStructor any value like
const {couseInstructor:instructor}=course
console.log(instructor);//Output=>Hitesh Chaudhary

//{
//     "name":"Hitesh",
//     "courseName":"Js in Hindi",
//     "price":"free",
//}