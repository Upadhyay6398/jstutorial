<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scope in JavaScript</title>
</head>
<body>
<h3>Scope in JavaScript</h3>
<script src="scope.js" type="text/JavaScript"></script>
</body>
</html>