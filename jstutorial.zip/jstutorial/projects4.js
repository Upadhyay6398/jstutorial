// Set the default time zone, e.g., 'UTC' or 'America/New_York'
let timeZone = 'UTC';

// Function to update the time and clock hands based on the current time
function updateClock() {
  const now = new Date();
  const timeZoneOffset = new Date().toLocaleString("en-IN", { timeZone: timeZone });
  const localTime = new Date(timeZoneOffset);

  // Get the current hour, minute, second
  const hours = localTime.getHours();
  const minutes = localTime.getMinutes();
  const seconds = localTime.getSeconds();

  // Display the current time in a readable format
  document.getElementById('time').textContent = `${formatTime(hours)}:${formatTime(minutes)}:${formatTime(seconds)}`;
  document.getElementById('time-zone').textContent = timeZone;

  // Update the clock hands rotation
  document.querySelector('.hour-hand').style.transform = `rotate(${(360 / 12) * (hours % 12)}deg)`;
  document.querySelector('.minute-hand').style.transform = `rotate(${(360 / 60) * minutes}deg)`;
  document.querySelector('.second-hand').style.transform = `rotate(${(360 / 60) * seconds}deg)`;
}

// Function to format hours, minutes, and seconds to always show two digits
function formatTime(timeUnit) {
  return timeUnit < 10 ? `0${timeUnit}` : timeUnit;
}

// Call updateClock every second
setInterval(updateClock, 1000);

// Set the initial time
updateClock();
