var config={
    cUrl:"https://api.countrystatecity.in/v1/countries",
    cKey:"NHhvOEcyWk50N2Vna3VFTE00bFp3MjFKR0ZEOUhkZlg4RTk1MlJlaA==",
}
var countrySelect=document.querySelector('#country')
var stateSelect=document.querySelector('#state')
var selectCity=document.querySelector('#city')

function loadCountries()
{
    let apiEndPoint=config.cUrl;
   fetch(apiEndPoint,{headers:{"X-CSCAPI-KEY":config.cUrl}}).then(Response=>Response.json()).then(data=>{
    data.foorEach(country=>{
        const option =document.createElement('option')
        option.value=country.iso2
        option.textContent=country.name
        countrySelect.appendChild(option);
    });
   })
   .catch(console.error('Error Loading Countries',error));
}

function loadStates()
{
    const selectCountryCode = countrySelect.value;
    stateSelect.innerHTML="<option>Select State</option>";
}