//What is Events 

//Events is like imagine a button on a webpage that says "Click Me." When you click the button, that "click" is the event. You can then define what should happen, like showing a message or changing the button's color, in response to that event...

//If we click on the India Flag then it show an alert like This is an India flag Image
document.getElementById('image2').addEventListener('click',function(){
    console.log("India Image click")
})

document.getElementById('image3').addEventListener('click',function(){
    console.log("Bsk Image Click")
})