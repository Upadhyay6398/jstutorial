// Generate a random number between 1 and 100
const randomValue = Math.floor(Math.random() * 100) + 1;
console.log(randomValue)
const submit = document.querySelector('#submit');
const guessNumber = document.querySelector('#guess');
const previousGuess = document.querySelector('.previousGuess');
const totalAttempt = document.querySelector('.totalAttempt');
const restart = document.querySelector('.restart');

let prevGuess = [];
let numGuess = 1;
let playGame = true;

if (playGame) {
    submit.addEventListener('click', function (e) {
        e.preventDefault();
        const guess = parseInt(guessNumber.value);
        validateGuess(guess);
    });
}

function validateGuess(guess) {
    // Validate the guess
    if (isNaN(guess)) {
        alert("Please enter a valid number.");
    } 
    else if (guess < 1 || guess > 100)
    {
        alert('Please enter a number between 1 and 100.');
    }
         else 
         {
        prevGuess.push(guess);
        if (numGuess === 10) 
            {
            displayGuess(guess);
            displayMessage(' You Loss ! Please restart for a new game.');
            endGame();
        } 
        else {
            displayGuess(guess);
            checkGuess(guess);
        }
        }
}

function checkGuess(guess) {
    // Check if the guess is correct, lower, or Higher
    if (guess === randomValue) {
        displayMessage('Your guess is correct!');
        gameWon=true
        endGame();
    } else if (guess < randomValue) {
        displayMessage('The number is too low.');
    } else {
        displayMessage('The number is too high.');
    }
}

function displayGuess(guess) {
    previousGuess.innerHTML = prevGuess.join(', ');
    numGuess++;
    totalAttempt.innerHTML = `Attempts: ${11-numGuess}`;
    guessNumber.value = ''; 
}

function displayMessage(message) {
    alert(message); 
}

function endGame() {
    playGame = false;
    submit.disabled = true;
    restart.style.display = 'inline-block'; 
}

// Restart the game
restart.addEventListener('click', function () {
    location.reload(); 
});
