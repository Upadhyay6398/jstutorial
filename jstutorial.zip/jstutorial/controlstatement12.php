<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control Statement In JavaScript</title>
</head>
<body>
<h3>Control Statement In JavaScript</h3>
<script src="controlstatement.js" type="text/Javascript"></script>
<script src="controlstatement2.js" type="text/Javascript"></script>
<script src="conditionaltruthy3.js" type="text/Javascript"></script>
</body>
</html>