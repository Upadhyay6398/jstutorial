//Functions are one of the fundamental building blocks in JavaScript.
// A function definition (also called a function declaration, or function statement) consists of the function keyword, followed by:

// The name of the function.
// A list of parameters to the function, enclosed in parentheses and separated by commas.

//Function is a Basic Building Blocks in of a Program with the help of function we can reuse the code...

function sayMyName()
{
    console.log("Braj Mohan Upadhyay");
}
sayMyName();

function sumOfTwoNumbers(a,b)
{
    return a+b;
}
console.log(sumOfTwoNumbers(10,20));

function multiplicationOfTwoNumbers(a,b)//Here a,b are called Perameters but when we call the function and those value we passed it is known as arguments
{
   console.log(a*b);
}
const result=multiplicationOfTwoNumbers(10,20);//Ouput=>200 Suppose if we defined the value Null in place of 20 it will provide the output 0 and if we defined the value Undefined in place of 20 then it will provide the result Nan...
console.log("Result",result)//Output=>Udefined because result is not return any value


function subOfTwoNumbers(a,b)
{
    let result1=a-b
    return result1;
    console.log("Hitesh")//It is not executed beacuse function is already return
}
const result1=subOfTwoNumbers(20,10)
console.log("Result:",result1);//Output=>Result: 10 Here Result value is 10 because it is return the value...

function userLoggedIn(username)
{
    if(username===undefined)
    {
        console.log("Please Enter Username")
        return
    }
    else
    {
    return `${username} Welcome to Our Website`
    }
}
console.log(userLoggedIn("Braj Mohan Upadhyay"));

//Undefined value is always provide the false result