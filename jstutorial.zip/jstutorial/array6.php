<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array in JavaScript</title>
</head>
<body>
<h2>Array In JavaScript</h2>

<!-- <td align="left" bgcolor="#FFFFFF"><?php echo date('d-m-Y h:i:s A', strtotime($rs['tstp']))?></td> --><!--For Change the Date Formate -->
<script src="array.js" type="text/Javascript"></script>
<script src="array2.js" type="text/Javascript"></script>
</body>
</html>