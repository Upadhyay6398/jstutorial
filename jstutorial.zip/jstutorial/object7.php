<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Object In JavaScript</title>
</head>
<body>
<h3>Object in JavaScript</h3>
<script src="object.js"  type="text/JavaScript"></script>
<script src="object2.js" type="text/JavaScript"></script>
<script src="object3.js" type="text/JavaScript"></script>
</body>
</html>