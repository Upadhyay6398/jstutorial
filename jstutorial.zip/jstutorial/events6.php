<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Submit Event Example</title>
</head>
<body>
  <form id="myForm" onsubmit="validateForm(event)">
    <input type="text" id="nameInput" placeholder="Enter your name">
    <div id="nameErr" style="color:red"></div><br>
    <button type="submit">Submit</button>
  </form>
  <p id="message" style="color: green;"></p>

  <script>
    function validateForm(event)
    {
        const nameErr=document.getElementById('nameErr')
        const name=document.getElementById('nameInput').value
        
    valid=true
    if(name==="")
    {
        document.getElementById('nameErr').innerHTML="Name is Required"
        valid= false;
    }
    if(!valid)
    {
        event.preventDefault();
    }
    if(valid)
    {
        document.getElementById('message').innerHTML="Form Submitted Successfully";
        valid=true
        event.preventDefault();
    }
    }
  </script>
</body>
</html>
