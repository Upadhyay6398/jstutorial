
//For in Loop in JavaScript...

const myObject={
    js:"JavaScript",
    cpp:"C Programming",
    rb:"Ruby",
    swift:"Swift by apple",
    py:"Python",
}
for(const key in myObject)
{
    console.log(key)//Ouput=>js
    //cpp
    //rb
    //swift
    //py
//This loop are used to print the key of the Objects
}
for(const key in myObject)
{
    console.log(myObject[key])//Output=>JavaScript
    //C Programming
    //Ruby
    //Swift by apple
    //Python
console.log(`${key} shortcut(extension) is ${myObject[key]}`)
//This Loop are used to print the Values of the Objects
}

//Note map is not and Iteratable we can not apply itertion on Map...

// for-in: Used for iterating over keys/properties (indexes in arrays or property names in objects).

// for-of: Used for iterating over values (actual data/elements in an iterable like an array, string, or map).