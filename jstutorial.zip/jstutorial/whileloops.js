//While Loop In JavaScript

let i=1;
while(i<=10)
{
    console.log(`Value of I is ${i}`)
    i++;
}
const myArray=["Apple","Bananan","Orange","PineApple","Date","Pear","Guavava","Papaya","Grapes"]

let condition=0
while(condition<myArray.length)
{
    let element=myArray[condition]
    console.log(element)
    condition++
}