
//How we can create a sets
//Set is an Object Set is store only unique value 

let mySet = new Set();

console.log(typeof mySet)//Output=>Object

//Another method to Declear Sets

mySet.add("a")
mySet.add("b")
mySet.add("c")
mySet.add("d")
console.log(mySet)//Output {'a','b','c','d'}

const number=new Set([1,2,3,5,6])
console.log(number)

//Checking the Size of Set

console.log(mySet.size)//Ouput=>4

//Checking if an Item Exists in a Set

console.log(mySet.has(5))//Output=>False
console.log(mySet.has('a'))//Output=>True

//Deleting Elements from a Set
mySet.delete('a')
console.log(mySet)//Output=>{'b', 'c', 'd'}

//Clear the entire Set

// mySet.clear();
console.log(mySet)//Output=>(0)

const uniqueNumbers = new Set([1, 2,2,2,2,2, 3, 4, 5, 2, 3]);
console.log(uniqueNumbers)//Output=>{1, 2, 3, 4, 5}

//Add any elememt is last of the array
uniqueNumbers.add(6)
console.log(uniqueNumbers)//output=>{1,2,3,4,5,6}

//Delete any element in a set
uniqueNumbers.delete(3)
console.log(uniqueNumbers)

const mySet1 = new Set([1, 2, 3, 4, 5]);
mySet1.forEach(value => {
  console.log(value);  // Logs each value in the Set
});

// Array: Allows duplicate values, values are indexed (accessed via an index).
// Set: Ensures unique values, no indexing (values are accessed only in iteration).

const value="33";
console.log()