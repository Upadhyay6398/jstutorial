<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chaining in JavaScript</title>
</head>
<body>
<script src="chaining.js" type="text/JavaScript"></script>
</body>
</html>