//Here We Discussed about the High Order (Advance Loops)....

// [" "," "," "]  this is an Array with String...
//[{},{},{}] this is an Array with in Objects...

//For of loops in JavaScript....

const myArray=[1,2,3,4,5]

for(const iterator of myArray)
{
    console.log(iterator)
}  //Ouptut=>1,2,3,4,5

const greetings="Hello World"
for(const greet of greetings)
{
    console.log(`Each Character is ${greet}`)
}

//+++++++++++++++++++++++++++++ Maps +++++++++++++++++++++++++++++++++
//The Map object holds key-value pairs and remembers the original insertion order of the keys...

const map=new Map()
map.set("IN","INDIA")
map.set("USA","United States of America")
map.set("Fr","France")
console.log(map)//Output=>{'IN' => 'INDIA', 'USA' => 'United States of America', 'Fr' => 'France'}
console.log(typeof map)//Output=>Object

//Map is Store Only Unique Value it here we can not store the duplicate value...
//Suppose we are store map.set("IN","INDIA") 2 times then it is show only one time because there is no duplicacy allowed here only unique value allowed here...


const map1=new Map()
map1.set("IN","INDIA")
map1.set("USA","United States of America")
map1.set("Fr","France")
map1.set("IN","INDIA")
map1.set("IN","INDIA")
map1.set("USA","United States of America")
console.log(map1)//Ouptput=> {'IN' => 'INDIA', 'USA' => 'United States of America', 'Fr' => 'France'} there is no duplicacy allowed here or humne jis order me like h usi order me aayegi values 

//How to apply Loops on Maps...

for([key,value] of map)
{
    console.log(key,':-',value);
}
//Output=>IN :- INDIA
//  USA :- United States of America
//  Fr :- Francel