
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Modern Buildtech : Property Consultant in Faridabad</title>
<meta content="" name="description">
<meta content="" name="author">
<meta content="" name="keywords">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style>
.contact-form {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background-color: #FFFFFF;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
.form-group {
  margin-bottom: 10px;
}

.form-label {
  font-size: 14px;
  font-weight: 600;
  color: #333;
  display: block;
}

.form-control {
  width: 100%;
  font-size: 14px;
  border: 1px solid #ddd;
  border-radius: 5px;
  transition: border-color 0.3s ease;
}

.form-control:focus {
  border-color: #5c6bc0;
  outline: none;
}

.btn-submit {
  background-color: #0c2338;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  width: 100%;
  transition: background-color 0.3s ease;
}

.btn-submit:hover {
  background-color: #3e4a89;
}

@media (max-width: 768px) {
  .contact-form {
    padding: 15px;
  }

  .form-control {
    font-size: 16px;
  }

  .btn-submit {
    padding: 12px;
  }
}

</style>
</head>
<body>
<!-- preloader start -->
<form method="POST" class="contact-form" name="enquiryForm" id="" onsubmit="validateForm(event)">
  <div class="form-group">
    <label for="name" class="form-label">Full Name</label>
    <input type="text" id="name" name="name" class="form-control" autocomplete="off" placeholder="Please Enter your Name">
    <div id="nameError" style="color:red"></div>
  </div>

  <div class="form-group">
    <label for="email" class="form-label">Email Address</label>
    <input type="email" id="email" name="email" class="form-control" autocomplete="off" placeholder="Please Enter Your Email Address">
    <div id="emailError" style="color:red"></div>
  </div>

<div class="form-group">
    <label for="phone" class="form-label">Phone Number</label>
    <input id="phone"  placeholder="Please Enter Your Mobile Number" class="form-control"
    aria-label="Your Mobile" aria-describedby="button-addon2" name="phone" maxlength="10" minlength="10"
    inputmode="numeric" pattern="[6789][0-9]{9}" data-parsley-type="digits"
    data-parsley-length-message="Please enter only 10 digits mobile no"
    data-parsley-pattern="[6789][0-9]{9}" data-parsley-pattern-message="Please enter a valid phone number"
    data-parsley-required="true" autocomplete="off"  oninput="this.value = this.value.replace(/\D/g, '')">                
    <div id="phoneError" style="color:red"></div>
</div>

  <div class="form-group">
    <label for="message" class="form-label">Message</label>
    <textarea id="message" name="message" class="form-control" rows="4" autocomplete="off" placeholder="Please Enter your Message"></textarea>
    <div id="messageError" style="color:red"></div>
  </div>

  <input type="hidden" name="source" value="Contact Us">

  <div class="form-group">
    <input name="submit" id="submit" type="submit" class="btn-submit" value="Submit"/>
  </div>

  <div id="errorMessage" style="color:red;"></div>
</form>
<script src="formvalidation.js"></script>

</html>