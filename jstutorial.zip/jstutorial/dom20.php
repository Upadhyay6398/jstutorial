<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dom Manipulation in JavaScript</title>
<style>
    .bg-black
    {
        background-color: #212121;
        color: #ffff;
    }
</style>
</head>
<body class="bg-black">
<h3>Dom Manipulation in JavaScript</h3>
<div>
    <h1 class="heading" id="title">Dom Learning on Chai or Code <span style="display:none">This is an JavaScript Code</span></h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus, facilis nihil unde quo veniam laborum quas rerum at fugit adipisci quaerat harum nam? Quod hic dicta iste rem ea explicabo...</p>
    <h2>JavaScript is written by Brandam Eich</h2>
    <h1>JavaScript By Chai Or Code</h1>
    <input type="password" name="password" id="password" placeholder="Please Enter Your Password">

    <ul>
        <!--This is an Type of Document Object Model-->
        <li class="list-item">One</li>
        <li class="list-item">Two</li>
        <li class="list-item">Three</li>
        <li class="list-item">Four</li>
        <li class="list-item">Five</li>
        <li class="list-item">Six</li>
    </ul>
</div>
<script src="dom.js"></script>
<script src="dom2.js"></script>
</body>
</html>
