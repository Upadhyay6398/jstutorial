"use strict";
let name="Braj Mohan Upadhyay";
console.log(name.length);
let number=50
// console.log(name+number);
console.log(`Hello My name is ${name} and My Number is ${number}`)
const anotherName=new String("Sachin Sharma");//It is used to access to prototype of any String
console.log(anotherName)
console.log(anotherName[0])
const thirdName="Aditya Yadhav"
console.log(thirdName.__proto__) //It is the Second method to access the prototype of String
//Some String Functions
console.log(thirdName.length);
console.log(thirdName.toUpperCase());
console.log(thirdName.toLowerCase());
console.log(thirdName.charAt(2));
console.log(thirdName.indexOf('i'));
const secondName= name.substring(-19,10);
console.log(secondName);
const anotherString=name.slice(-19,1);
console.log(anotherString);

const secondValue="     hitesh       "
console.log(secondValue);
console.log(secondValue.trim());

const url="Successfully%20login";
console.log(url.replace('%20','-'));

console.log(url.includes('Successfully'));//Ouptut=>true

//Note Convert Array to String in JavaScript are used

const fourthName="Braj Mohan Upadhyay";
console.log(fourthName.split(' '));
const words=fourthName.split(' ');
console.log(words);
console.log(words[2]);

//We Want Output of this type like Hey My Name is "Braj Mohan Upadhyay";

const str="Hey My Name is \"Braj Mohan Upadhyay\"";
console.log(str);

const str1 = 'Hello';
console.log(str1.charCodeAt(0)); // Output: 72 (Unicode value of 'H')  Here 0 is the Index Number


//It is Search in a String From the Last
let str2 = 'Hello, world! Hello!';
console.log(str.lastIndexOf('world')); // Output: -1

let str3 = 'Hello, world!';
console.log(str3.startsWith('Hello')); // Output: true
console.log(str3.startsWith('world')); // Output: false

let str4 = 'Hello, world!';
console.log(str4.endsWith('world!')); // Output: true /1
console.log(str4.endsWith('Hello')); // Output: false

const newString=new String("Gaurav Pandit");
console.log(typeof newString);