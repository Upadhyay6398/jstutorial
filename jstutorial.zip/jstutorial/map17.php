<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Map in JavaScript</title>
</head>
<body>
    <h3>Map in JavaScript</h3>
<script src="map.js" type="text/JavaScript"></script>
</body>
</html>