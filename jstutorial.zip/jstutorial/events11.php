<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Unload Event Example</title>
</head>
<body>
  <p>Try leaving this page!</p>

  <script>
    window.addEventListener("unload", function() {
      alert("Goodbye! You are leaving the page.");
    });
  </script>
</body>
</html>
