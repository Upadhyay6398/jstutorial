function addlanguage(language)
{
  const value=  document.createElement('li')
  value.innerHTML=`${language}`
  document.querySelector('.language').appendChild(value)

}
addlanguage('C Programming')
addlanguage('TypeScript')
addlanguage('Java')

//Add Optimize Way Language
function addOptimizeLanguage(language)
{
 const anotherValue= document.createElement('li')
 anotherValue.appendChild(document.createTextNode(language))
 document.querySelector('.language').appendChild(anotherValue)
}
addOptimizeLanguage('Php')
addOptimizeLanguage('Codeigniter')
addOptimizeLanguage('Laravel')

//Edit li element
const secondLanguage=document.querySelector('li:nth-child(2)')
// secondLanguage.innerHTML="JavaScript"
const newli=document.createElement('li');
newli.textContent="Mojo"
secondLanguage.replaceWith(newli)


//Second Edit Method
const firstChild=document.querySelector('li:first-child')
firstChild.outerHTML='<li>React Js</li>'

//Remove 
const lastChild=document.querySelector('li:last-child')
lastChild.remove()