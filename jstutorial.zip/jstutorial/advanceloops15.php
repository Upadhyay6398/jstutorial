<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advance Loops Of JavaScript</title>
</head>
<body>
<h3>Advance Loops of JavaScript</h3>
<script src="advanceloops.js" type="text/JavaScript"></script>
<script src="advanceloops2.js" type="text/JavaScript"></script>
<script src="advanceloops3.js" type="text/JavaScript"></script>
<script src="advanceloops4.js" type="text/JavaScript"></script>
</body>
</html>