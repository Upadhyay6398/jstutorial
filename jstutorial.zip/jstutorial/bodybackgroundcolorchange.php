<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body id="body">
<style>
        body 
        {
            background-color: white;
        }
        button
        {
            margin-left: 50%;
            margin-top: 50vh;
            padding: 2px;
        }
    </style>
     <button onclick="changeColor()">Change Color</button>
<script>
    const body=document.getElementById('body').style
    const colors = ["red", "blue", "green", "pink", "white", "purple", "grey", "orange", "yellow"]
    function changeColor () {
    body.backgroundColor = colors[Math.floor(Math.random() * colors.length)]
}
</script>
</body>
</html>