<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Form</title>
  <link rel="stylesheet" href="styles.css">
</head>
<style>
  /* Global Styles */
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: Arial, sans-serif;
    background-color: #f4f7fa;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    position: relative;
  }

  /* Container Styles */
  .container {
    background-color: #ffffff;
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
    text-align: center;
  }

  /* Heading Style */
  h2 {
    margin-bottom: 20px;
    color: #333;
  }
  .form-group {
    margin-bottom: 20px;
    text-align: left;
  }
  label {
    font-size: 14px;
    color: #333;
    font-weight: 600;
    display: block;
    margin-bottom: 5px;
  }
  input, textarea {
    width: 100%;
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 4px;
    transition: border-color 0.3s ease;
  }

  input:focus, textarea:focus {
    border-color: #5b9bd5;
    outline: none;
  }
  .submit-btn {
    width: 100%;
    padding: 12px;
    background-color: #5b9bd5;
    color: #fff;
    font-size: 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  .submit-btn:hover {
    background-color: #4a86b7;
  }

  /* Popup Modal Styles */
  .popup {
    display: none; /* Initially hidden */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Transparent dark background */
    justify-content: center;
    align-items: center;
  }

  .popup-content {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    text-align: center;
    position: relative;
    width: 100%;
    max-width: 600px;
  }

  .close-btn {
    position: absolute;
    top: 10px;
    left: 20px;
    font-size: 25px;
    font-weight: bold;
    color: #333;
    cursor: pointer;
  }

  /* Responsive Styles */
  @media (max-width: 768px) {
    .container {
      padding: 30px;
    }
    h2 {
      font-size: 24px;
    }
    .form-group {
      margin-bottom: 15px;
    }
  }

</style>
<body>
  <div class="popup" id="popup">
    <div class="popup-content">
      <span class="close-btn" onclick="closePopup()">&times;</span>
      <div class="container">
        <h2>Contact Us</h2>
        <form action="#" method="POST" class="contact-form">
          <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" placeholder="Enter your full name" required>
          </div>
          <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
          </div>
          <div class="form-group">
            <label for="mobile">Mobile Number</label>
            <input type="tel" id="mobile" name="mobile" placeholder="Enter your mobile number" required>
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="5" placeholder="Write your message here" required></textarea>
          </div>
          <button type="submit" class="submit-btn">Submit</button>
        </form>
      </div>
    </div>
  </div>

<script>
    function showPopup()
    {
      const popup = document.getElementById('popup');
      popup.style.display = 'flex';
    }
    function closePopup()
    {
      const popup = document.getElementById('popup');
      popup.style.display = 'none';
    }
    setTimeout(showPopup, 10000);
    document.getElementById('popup').addEventListener('click', function(event)
    {
      if (event.target === this) 
      {
        closePopup();
      }
    });
</script>
</body>
</html>
