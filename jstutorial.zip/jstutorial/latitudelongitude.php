<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Get User Location</title>
</head>
<body>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: Arial, sans-serif;
  background-color: #f4f4f4;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.container {
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  text-align: center;
  width: 300px;
}

h1 {
  margin-bottom: 20px;
}

button {
  padding: 10px 20px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  margin-bottom: 20px;
}

button:hover {
  background-color: #45a049;
}

#output {
  margin-top: 20px;
}
p {
  font-size: 14px;
  margin: 8px 0;
}

#status {
  font-weight: bold;
}

    </style>
<div class="container">
    <h1>Find Your Location</h1>
    <button onclick="getLocation()">Get My Location</button>
    <div id="output">
      <p id="status">Click the button to get your location.</p>
      <p><strong>Latitude:</strong> <span id="latitude">N/A</span></p>
      <p><strong>Longitude:</strong> <span id="longitude">N/A</span></p>
    </div>
</div>
<script>
function getLocation() {
  if (navigator.geolocation)
   {
    navigator.geolocation.getCurrentPosition(function(position) 
    {
      const latitude = position.coords.latitude;
      const longitude = position.coords.longitude;
      document.getElementById("status").textContent = "Location found!";
      document.getElementById("latitude").textContent = latitude;
      document.getElementById("longitude").textContent = longitude;
    }
    , function(error)
    {
      document.getElementById("status").textContent = "Error occurred: " + error.message;
      document.getElementById("latitude").textContent = "N/A";
      document.getElementById("longitude").textContent = "N/A";
    });
    } 
    else 
    {
    document.getElementById("status").textContent = "Geolocation is not supported by this browser.";
    }
}
</script>
</body>
</html>
