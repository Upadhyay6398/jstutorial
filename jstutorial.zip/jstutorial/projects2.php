<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMI Calculator</title>
<style>
    /* styles.css */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.container {
    background-color: #ffffff;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
}

h1 {
    color: #333;
    margin-bottom: 30px;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    font-size: 1rem;
    color: #555;
    margin-bottom: 5px;
    text-align: left;
}

input, select {
    padding: 10px;
    margin-bottom: 20px;
    font-size: 1rem;
    border-radius: 5px;
    border: 1px solid #ccc;
}

button {
    padding: 10px;
    font-size: 1rem;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}

#result {
    margin-top: 30px;
    display: none;
}

#bmi-value {
    font-size: 2rem;
    font-weight: bold;
}

#category {
    font-size: 1.2rem;
    color: #555;
}

</style>
</head>

<body>
    <div class="container">
        <h1>BMI Calculator</h1>
        <form id="bmi-form">
            <label for="weight">Weight (kg):</label>
            <input type="text" id="weight" >

            <label for="height">Height:</label>
            <input type="number" id="height" >
            
            <label for="unit">Select Height Unit:</label>
            <select id="unit" >
                <option value="" disabled selected>Select Height</option>
                <option value="cm">Centimeters (cm)</option>
                <option value="inches">Inches (in)</option>
            </select>

            <button type="submit">Calculate BMI</button>
        </form>

        <div id="result" style="display:none;"> <!-- Initially hidden -->
        <h2>Your BMI: <span id="bmi-value"></span></h2>
        <p id="category"></p>
        </div>

    </div>

    <script src="projects2.js"></script>
</body>
</html>
