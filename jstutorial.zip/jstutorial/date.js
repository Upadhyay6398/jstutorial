//JavaScript Date objects represent a single moment in time in a platform-independent format. Date objects encapsulate an integral number that represents milliseconds since the midnight at the beginning of January 1, 1970, UTC (the epoch).


//Date : Date is an object in javascript. 
// JavaScript stores dates as number of milliseconds since January 01, 1970
const myDate = new Date();

console.log(myDate) //Output : 2023-10-09T14:38:09.847Z

// We can use various methods to convert this date into more readable value.
console.log(myDate.toString()) //Output : Mon Oct 09 2023 07:39:18 GMT-0700 (Pacific Daylight Time)

console.log(typeof myDate);//Output=>Object

console.log(myDate.toLocaleString()) // Output : 15/01/2025, 7:44:20 AM //format MM/DD//YY
console.log(myDate.toLocaleDateString()) //Output :15/01/2025
console.log(myDate.toLocaleTimeString()) // Output : 7:45:31 AM

console.log(myDate.toDateString()) //Output : Mon Oct 09 2023
console.log(myDate.toTimeString()) // Output : 07:46:40 GMT-0700 (Pacific Daylight Time)

console.log(myDate.toISOString()) // Output : 2023-10-09T14:43:39.337Z
console.log(myDate.toJSON()) //Output : 2023-10-09T14:40:58.495Z

//Note:-Month Will be Start on 0 in JavaScript

const myCreatedDate=new Date(2024,0,11);
console.log(myCreatedDate);//Output=>Thu Jan 11 2024 00:00:00 GMT+0530 (India Standard Time)
console.log(myCreatedDate.toDateString());//Thu Jan 11 2024
//Note Suppose We Want a Specific Format of Date

const anotherCreatedDate=new Date("02-02-2024");
console.log(anotherCreatedDate.toDateString());//Tue Feb 28 2023


const myTimeStamp=Date.now();
console.log(myTimeStamp);//Output=>1736590545871

const newDate=new Date();
console.log(newDate.getDate());//Optput=>11 Suppose We Want to Get only Date then use it

console.log(newDate.getMonth());//Output=>1 because Month will be started form 0 and on going month is February