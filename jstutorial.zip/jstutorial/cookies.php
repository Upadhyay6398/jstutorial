<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookies Alert</title>
</head>

<style>
.cookie-banner
{
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
	background-color: #2C3E50;
	color: white;
	padding: 15px 20px;
	display: flex;
	justify-content: space-between;
	align-items: center;
	font-size: 14px;
	box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.2);
}
.cookie-banner p {
	margin: 0;
	flex: 1;
}
.cookie-button {
	padding: 10px 20px;
	border: none;
	background-color: #3498DB;
	color: white;
	cursor: pointer;
	border-radius: 5px;
	margin-left: 10px;
}
.cookie-button.reject 
{
	background-color: #E74C3C;
}
.cookie-button:hover
{
	opacity: 0.8;
}
.hidden
{
	display: none;
}
</style>
<body>
<div class="cookie-banner" id="cookieBanner">
        <p>We use cookies to improve your experience on our site. By clicking "Accept All Cookies," you consent to our use of cookies.</p>
        <div>
            <button class="cookie-button" id="acceptBtn">Accept All Cookies</button>
            <button class="cookie-button reject" id="rejectBtn">Reject All Cookies</button>
        </div>
</div>
</body>
<script>
    const cookiesBanner=document.getElementById('cookieBanner')
    const acceptBtn=document.getElementById('acceptBtn')
    const rejectBtn=document.getElementById('rejectBtn')

	//Check if Cookies is already accept or Rejected
	if(localStorage.getItem('cookiesAccepted')||localStorage.getItem('cookiesRejected'))
	{
		cookiesBanner.classList.add('hidden')
	}
	//if Cookies is Accept By user
        acceptBtn.addEventListener('click',function(){
			localStorage.setItem('cookiesAccepted', 'true');
            cookiesBanner.classList.add('hidden')
            alert('Cookies is Accept')
        });
        rejectBtn.addEventListener('click',function(){
			localStorage.setItem('cookiesRejected', 'true');
            cookiesBanner.classList.add('hidden')
            alert('Cookies is Rejected')
        })
</script>
</html>