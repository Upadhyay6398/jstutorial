<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dependent Dropdown</title>
    
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            color: #4e5d6b;
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            font-weight: 600;
            color: #4e5d6b;
            margin-bottom: 8px;
            display: block;
        }

        select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ccd1d9;
            border-radius: 5px;
            background-color: #fafbfc;
            font-size: 16px;
            color: #4e5d6b;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        select:focus {
            outline: none;
            border-color: #6c8ea3;
            background-color: #ffffff;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 12px;
            font-size: 16px;
            color: #fff;
            background-color: #4e5d6b;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background-color: #3b4c62;
        }

        .btn:focus {
            outline: none;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Location Selector</h1>
        
        <label for="country">Country:</label>
        <select id="country" name="country" onchange="loadStates()">
            <option value="">Select Country</option>
        </select>

        <label for="state">State:</label>
        <select id="state" name="state" onchange="loadCities()">
            <option value="">Select State</option>
        </select>

        <label for="city">City:</label>
        <select id="city" name="city">
            <option value="">Select City</option>
        </select>

        <button class="btn" >Submit</button>
    </div>
    <script src="dependentdropdown.js"></script>
</body>
</html>
