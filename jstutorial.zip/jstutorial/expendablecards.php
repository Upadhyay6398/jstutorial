<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expandable Card</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>
    .card {
    width: 300px;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #f9f9f9;
}

.card-text {
    max-height: 100px;
    overflow: hidden;
    text-overflow: ellipsis;
}

button {
    background-color: #007bff;
    color: white;
    padding: 10px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
}

button:hover {
    background-color: #0056b3;
}

</style>
<body>
    <div class="card">
        <p class="card-text" id="card-text">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vehicula urna vel diam consectetur, et hendrerit lorem sollicitudin. Aliquam erat volutpat. Fusce id leo dui. Nulla facilisi. Integer sit amet lectus felis. Sed fermentum turpis vitae sem laoreet, ac interdum metus mollis. Ut condimentum tincidunt turpis, et efficitur tortor tempor vitae. Maecenas id mauris vel nunc interdum vulputate ut sed sapien. Cras posuere, lectus a tempor auctor, arcu dui dignissim augue, at mollis est lectus vel sapien. Suspendisse cursus ante eu magna fermentum, a lobortis magna fermentum. 
        </p>
        <button class="btn" id="toggle-button" onclick="toggleText()">Read More</button>
    </div>

    <script>
        function toggleText() {
    const cardText = document.getElementById('card-text');
    const button = document.getElementById('toggle-button');

    if (cardText.style.maxHeight === 'none') {
        cardText.style.maxHeight = '100px';
        button.textContent = 'Read More';
    } else {
        cardText.style.maxHeight = 'none';
        button.textContent = 'Read Less';
    }
}

</script>
</body>
</html>
