const score=400;
console.log(typeof score);//Output=>Number

//Note:-Score value type is Number But Sometimes value is come from the Backend and they is send to the any user and we dont know about the value then to receive the value inform of Number then use it....

const balance=new Number(100);//It Will Always give the Value in form of Number
console.log(balance);//Ouptut=>Number Always....

//Change Number to String used toString()...

console.log((balance.toString())); //Ouput=>100 It is String type

console.log(typeof(balance.toString()));//Output=>String

console.log(balance.toString().length);//Output=>3

//Suppose We Are Developing an Ecommerce Website then we want ouput like 100.00 then We use toFixed()

console.log(balance.toFixed(2));//Ouput=>100.00

console.log(balance.toFixed(3));//Output=>100.000

//Note:- If we want to find the Precision Value of any Number are used

const anotherNumber=124.9055555
console.log(anotherNumber.toPrecision(4));//Ouptput=>124.9

const hundred=100000
console.log(hundred.toLocaleString('en-IN'));//Output=>1,00,000


//+++++++++++++++++++++++++ Maths In JavaScript ++++++++++++++++++++++++++++++++

console.log("+++++++++++++++++++++ Maths ++++++++++++++++++++++++++++++++++++++");//It is Just used to better understanding thats Maths Portation is Started here he is looks in console.... 

//Note:---Maths is a Object in JavaScript...

console.log(Math);//Output=>Object; and all Maths Function is show

//Suppose Value is Negative then if we want to change it in Posative the used abs();

console.log(Math.abs(-4));//Ouput=>4

//For the Roundoff if the decimal value is greater then or equal to 5 then it always choose bigger then otherwise it will choose same number 
console.log(Math.round(4.4));//Ouput=>4
console.log(Math.round(4.5));//Ouput=>5
console.log(Math.round(4.5));//Ouput=>5

//Suppose We Want to Control that it always choose the lower value and higher value

console.log(Math.ceil(4.2));//Ouput=>5
console.log(Math.floor(4.9));//Output=>4

console.log(Math.min(1,2,3,4,5,6,7));//Ouput=>1
console.log(Math.max(1,2,3,4,5,6,7,9));//Output=>9


//Math.random value Will be always greater then or equal to 1

console.log(Math.floor((Math.random()*10)+1));

const max=20;
const min=10;

console.log(Math.floor((Math.random()*(max-min+1))+10))