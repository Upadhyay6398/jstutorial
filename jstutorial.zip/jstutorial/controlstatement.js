
//If Condition

// const isUserLogin=true
// if(isUserLogin)
// {
//     console.log("Welcome to My Website Here you can read any Blog")
// }

//Comparision Operator:-<,>,>=,<=,==,!=,===
//Single Equal to is assignment operator and Double equal to is Comparision Opearator...

// if(2=="2")
// {
//     console.log("Executed")
// } Output=>Executed

// if(2==="2")
// {
//     console.log("Executed");
// } No Output is shown beacuse === is always check the datatype so this iteration it not executed...

// if(2!=="2")
// {
//     console.log("Executed");
// }
// //Ouptut=>Executed

const temperature=41
if(temperature<50)
{
    console.log("Temperature is less then 50")
}
else{
console.log("Teemerature is Greater then 50")
}