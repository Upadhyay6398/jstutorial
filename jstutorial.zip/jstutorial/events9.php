<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blur Event Example</title>
</head>
<body>
  <input type="text" id="nameInput" placeholder="Enter your name">
  <p id="message"></p>

  <script>
    document.getElementById("nameInput").addEventListener("blur", function() {
      document.getElementById("message").textContent = "Input field lost focus! "+this.value;
    });
  </script>
</body>
</html>
