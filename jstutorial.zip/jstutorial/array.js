// Array is written in brackets [  ].
// Array data type is an object.
// Array can contain different data types . i.e string,number,boolean etc
// Array is zero based indexing. It starts with zero.

//Note :- JavaScript Array are resizable..

//JavaScript array-copy operations create shallow copies.

const array=[1,2,3,4,5,true,"hitesh"];
console.log(typeof array);//Ouput=>Object Array is an Object type
const anotherArray=new Array(10,20,30,40);
console.log(typeof anotherArray);//Ouput=>Object
let fruits = new Array("apple", "banana", "cherry");//Another Way to Declear Array
console.log("Value of the  Index is "+array[0])//Output=>1

fruits.push("date")  //Adds "date" to end of the Array
console.log(fruits); //Output=>["apple","banana","cherry","date"]

fruits.pop();
console.log(fruits);//['apple', 'banana', 'cherry']

fruits.unshift("orange");
console.log(fruits);//Ouput=>['orange', 'apple', 'banana', 'cherry']

//Note:-Unshift Operation are used to add any value starting of the array whereas push() operation are used to add any value end of the array

fruits.shift();
console.log(fruits);//Output=> ['apple', 'banana', 'cherry']

//Noter:-Shift operation are used to remove any value starting of the array where as pop operation are used to remove value end of the array.....

console.log(fruits.includes("apple"));//Ouput=>true
console.log(fruits.length);//Ouput=>3
console.log(fruits.indexOf("banana"));//Output=>1 If the value is peresent  then the ouptput is index number of the array otherwise it return -1....


let result = fruits.join();//The join() method returns an array as a string.
console.log(result);  // Output: "apple,banana,cherry"

console.log(typeof result);//Output=>String 

//Note:-Join are return as a String


const array1=Array(7,2,3,4,5,6,7,8,9);
console.log(array1);
const myarray=array1.slice(1,3);//Last Number are not include it is provide the copy of the array
console.log("A",myarray);//Ouput=> [2, 3]


//Spice Original Array is [7,2,3,4,5,6,7,8,9]

const mysecondarray=array1.splice(1,3);//Last NUmber are included it is manipulated the orginal Array
console.log(mysecondarray)//Output=>[2,3,4]
//Slice Orignial Array is [7,5,6,7,8,9]

//Note:-Splice are Manipulated the Orginal Array Where as Slice are provided the Copy of the array suppose we have an array and we want to perform the slice operation on that then it will provide the copy of the original array and in case of splice operation it will provide remove the elements of the array

