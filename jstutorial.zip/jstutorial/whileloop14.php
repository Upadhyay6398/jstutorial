<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>While Loop In JavaScript</title>
</head>
<body>
    <h1>While Loop In JavaScript</h1>
<script src="whileloops.js" type="text/JavaScript"></script>
</body>
</html>