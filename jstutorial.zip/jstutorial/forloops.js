//Forloops In JavaScript
//For loops is an Entry Control Loops it is firstly check the condition and after enter into the loops...

for(let index=1; index<=10;index++)
{
    const element=index;
    console.log(element);
}

for(let i=1;i<=3;i++)
    {
        console.log(`INNER LOOP: ${i}`)
        
        for(let j=1;j<=3;j++)
        {
            console.log(`OUTER LOOP VALUE J IS: ${j} AND INNER LOOP VALUE I IS ${i}`)
        }
    }

    // for(let i=1;i<=10;i++)
    //     {
    //         console.log(`TABLE OF : ${i}`)
            
    //         for(let j=1;j<=10;j++)
    //         {
    //             console.log(i+'*'+j+'='+i*j)
    //         }
    //   }

    const myArray=["Apple","Bananan","Orange","PineApple","Date","Pear","Guavava","Papaya","Grapes"]
    console.log(myArray.length)
    for(let i=0;i<myArray.length;i++)
    {
       const element=myArray[i]
       console.log(element)
    }

//Break and Continue in JavaScript

for(let i=1;i<=20;i++)
{
    {
    console.log("Detected 5")
    break
    }
    console.log(i);
}