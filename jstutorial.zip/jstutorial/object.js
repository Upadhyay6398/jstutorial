//Objects Can be declear in two Types
//1..Literal(No Singleton)
//2..Constructor(Singleton)

//Jb bhi hum object of Literal ki tarah declear krte h to singleton nahi banta lakin constructor se banega to hamesa singleton banega

//How to Declear Object Literal
const mySymbol=Symbol("key");

const jsUser={

        name:"Braj Mohan",
        "full name":"Braj Mohan Upadhyay",
        age:22,
        mySym:"mykey1",
        [mySymbol]:"mykey2",
        location:"Jaipur",
        email:"brajmohanupadhyay@google.com",
        isLoggedIn:false,
        lastLoggedInDays:["Monday","Saturday"]
}

//This is the way to access Objects
console.log(jsUser.name)//Output=>Braj Mohan

//Another way to access objects

console.log(jsUser["location"]);//Output=>Jaipur=>this is the another method to access Objects....
console.log(jsUser["full name"])//Output=>Braj Mohan Upadhyay
//Note:-Full name is access only this method we can't access this method to first method


//How to declear Symbol


console.log( typeof mySymbol);//Output=>String it is type of String it is not treated as a Symbol

//Note if we want to declear a Symbol in Object then it's key is written in [] braces and it is also access in [] without any "" in square braces..

console.log(jsUser[mySymbol]);//Output=>mykey2

console.log(typeof jsUser[mySymbol])//Output=>Symbol

//How to Change the Object Values..

jsUser.email="brajmohanupadhyay@microsoft.in";
console.log(jsUser.email);//Output=>brajmohanupadhyay@microsoft.in

//Note:-Suppose if we want to no one  can't change my object value then we use Object.freeze method

// Object.freeze(jsUser)//Now No one can't change my object values

jsUser.isLoggedIn=true;
console.log(jsUser);//Output=>{name: 'Braj Mohan', full name: 'Braj Mohan Upadhyay', age: 22, mySym: 'mykey1', location: 'Jaipur', …}
//Here we can see that isLoggedIn value is not change because we are already freeze the Object....

//How to Use Function in Objects...

jsUser.greetings=function()
{
    console.log("Hello! Js User How are You");
}
console.log(jsUser.greetings());//Output=>Hello! Js User How are You

console.log(jsUser.greetings);//Ouput=>ƒ ()
// {
//     console.log("Hello! Js User How are You");
// } Here Function is not executed it gives only references

//Suppose we are refer the same object then use this like

jsUser.secondGreetings=function()
{
    console.log(`Hello ${this.name} you are loggedIn these days ${this.lastLoggedInDays}`);
}
console.log(jsUser.secondGreetings());//Ouput=>Hello Braj Mohan you are loggedIn these days Monday,Saturday 
//Suppose we are refer the same objects then we can use this in javaScript...