<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mouseout Event Example</title>
</head>
<body>
    <p>This event is triggered when the mouse pointer leaves an element.</p>
  <div id="hoverDiv" style="width: 200px; height: 100px; background-color: lightcoral;">
    Hover over me and then move your mouse out!
  </div>
  <p id="message"></p>

  <script>
    document.getElementById("hoverDiv").addEventListener("mouseout", function() {
      document.getElementById("message").textContent = "Mouse has left the div!";
    });
  </script>
</body>
</html>
