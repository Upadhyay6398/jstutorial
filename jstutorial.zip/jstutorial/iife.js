//Immediately Invoked Function Expression(IIFE)...

//Need of IIFE Function Suppose we are using Database connection in a file and we want that if we start a application and database connection is immediately invoked

//IIFE Function are used to remove Global Scope Polution and it is Invoked Immediately

//Simple Function
function dbConnection()
{
    console.log("DATABASE IS CONNECTED SUCCESSFUL")
}
dbConnection();

//IIFE Function

( function databseConnection()
//named IIFE
    {
        console.log("SECOND DATABASE IS CONNECTED SUCCESSFULLY")
    }
)();

//IIFE Function with Arrow Function...

(()=>{
    console.log("THIRD DATABASE IS CONNECTED SUCCESSFULLY")
}
)();

((name)=>{
    console.log(`${name} Welcome to My Website`)
}
)('Braj Mohan Upadhyay');

//Arrow Function in JavaScript

const name = () => {
    console.log( "Good Morning! This is an JavaScript" );
}

name();

const userName=(value)=>{
    return value;
}
console.log('Braj Mohan Upadhyay')