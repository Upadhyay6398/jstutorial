const form = document.querySelector('form');
form.addEventListener('submit', function (e) {
    e.preventDefault(); //

    const weight = parseInt(document.querySelector('#weight').value);
    const height = parseInt(document.querySelector('#height').value);
    const unit = document.querySelector('#unit').value;
    const result = document.querySelector('#result');

    if (weight === '' || weight < 0 || isNaN(weight)) {
        result.innerHTML = `Please Enter a Valid Weight ${weight}`;
        result.style.display = 'block';
        return;
    }

    if (height === '' || height < 0 || isNaN(height)) {
        result.innerHTML = `Please Enter a Valid Height ${height}`;
        result.style.display = 'block';
        return;
    }

    if (unit === '' || (unit !== 'cm' && unit !== 'inches'))
    { 

        result.innerHTML = `Please Select a Valid Height Unit (${unit})`;
        result.style.display = 'block';
        return;
    }

    let heightInMeters;
    if (unit === 'cm') 
    {
        heightInMeters = height / 100;
    }
        else if (unit === 'inches') 
        {

        heightInMeters = height * 0.0254;
        
        }

    const bmi = weight / (heightInMeters * heightInMeters);

    let category = '';
    if (bmi < 18.5)
    {
        category = "Underweight";
    } 
    else if (bmi >= 18.5 && bmi <= 24.9)
    {
        category = "Normal Weight";
    } 
    else if (bmi >= 25 && bmi < 29.9) 
    {
        category = "Overweight";
    }
    else 
    {
        category = "Obesity";
    }
    result.innerHTML = `
        <h2>Your BMI: ${bmi.toFixed(2)}</h2>
        <p>BMI Category: ${category}</p>
    `;
    result.style.display = 'block';
});
