<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Focus Event Example</title>
</head>
<body>
    <p>When you click into the input field, the message "Input field is focused!" will appear.</p>
  <input type="text" id="nameField" placeholder="Enter your name">
  <p id="message"></p>

  <script>
    document.getElementById("nameField").addEventListener("focus", function() {
      document.getElementById("message").textContent = "Input field is focused!";
    });
  </script>
</body>
</html>
