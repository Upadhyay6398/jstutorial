
//Difference b/w Query Selector or QuerySelectorAll


//It Select First h2 in the Html Webpage

// console.log(document.querySelector('h2')); //Output=>    <h2>JavaScript is written by Brandam Eich</h2>

//It Select that id is title
// console.log(document.querySelector('#title'));//Output=><h1 class="heading" id="title">Dom Learning on Chai or Code <span style="display:none">This is an JavaScript Code</span></h1>

//It Select that Class is title

//console.log(document.querySelector('.heading'));//Output=><h1 class="heading" id="title">Dom Learning on Chai or Code <span style="display:none">This is an JavaScript Code</span></h1>

//It Select that Input type is Password

//console.log(document.querySelector('input[type="password"]'))//Output=><input type="password" name="password" id="password" placeholder="Please Enter Your Password">

//I want to Change the background color of first li

// const value=document.querySelector('ul')

// const anotherValue=value.querySelector('li')

// anotherValue.style.backgroundColor="red"
// anotherValue.style.color="yellow"
// anotherValue.style.padding="15px"
// anotherValue.style.fontSize="20px"


//Suppose we want to Change the All li Color then use Foreach loop

// anotherValue.forEaach(function(l)
// {
//    l.style.backgroundColor="green"
// })

//**************************************************************************/
//******************* Now Concept of Query Selector All ********************/
//*************************************************************************/

//He is select all h1 are availavle on the Webpage
// const myH1=document.querySelectorAll('h1')
// console.log(myH1)
//Now we want to change the color of the second h1 then use it

//Its Index is start with Zero
// console.log(myH1[1].style.color="yellow")

//The Main Difference b/w QuerySelector and QuerySelectorAll 
//querySelector: Returns a single element (first match).
//querySelectorAll: Returns all matching elements (NodeList).


// const value=document.getElementsByClassName("list-item")
// console.log(value)//Output=>HTMLCollection(6) [li.list-item, li.list-item, li.list-item, li.list-item, li.list-item, li.list-item]

//How we Can Apply ForEach Loop On Html Collection We can Easily Apply ForEach loop on NodeList but If we want to apply forEach loop on Html then there are different method

// const anotherValue=Array.from(value)
// console.log(anotherValue)//Output=>[li.list-item, li.list-item, li.list-item, li.list-item, li.list-item, li.list-item]

// anotherValue.forEach(function(li){
//  li.style.color="Yellow"
// })