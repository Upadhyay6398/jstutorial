<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Variable In JavaScript</title>
</head>
<body>
    <p>Variable is Just like a Container it is used to store a Data value that we can change at the run time</p>
    <script src="variable.js" type="text/javascript"></script>
</body>
</html>