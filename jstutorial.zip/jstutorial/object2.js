//How to Declear Constructor(Singleton) Objects

const tinder=new Object()
const tinder1={}//ye bhi ek object hi h this is the method to declear constructor object
console.log(tinder);//Output=>{} 
console.log(typeof tinder) //Output=>Object

// How to declear value on Constructor(Singleton) Objects...
tinder.id="123abc"
tinder.name="Gaurav Sharma"
tinder.email="gruravsharma@google.com"
tinder.address="Aligarh"
console.log(tinder)//Output=>{id: '123abc', name: 'Gaurav Sharma', email: 'gruravsharma@google.com', address: 'Aligarh'}

const regularUser={
    email:"someone@gmail.com",
    fullname:{
        username:{
            firstName:"Braj",
            moddleName:"Mohan",
            lastName:"Upadhyay"
        }
    }
}

console.log(regularUser.fullname);
console.log(regularUser.fullname.username.firstName)

const obj1={
    1:"A",
    2:"B",
    3:"C",
    4:"D"
}

const obj2={
        5:"E",
        6:"F",
        7:"G",
        8:"H"
}

//How to merge two Objects...

const obj3={obj1,obj2}
console.log(obj3) //He is show the output object with in Object...

//Object.assign() method is the best way to combine two or more objects...

const obj4=Object.assign(obj1,obj2);
console.log(obj4);//Output=>{1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'E', 6: 'F', 7: 'G', 8: 'H'}

//Another Method to Combine two or more array Spread

const obj5={...obj1,...obj2}
console.log(obj5);//{1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'E', 6: 'F', 7: 'G', 8: 'H'}

const Users=[
    {
        id:"1",
        email:"brajmohan@innovativeinfonet.in"
    },
    {
        id:"2",
        email:"brajmohan@google.com"
    },
    {
        id:"3",
        email:"brajmohan@microsoft.com"        
    },
]
console.log(Users[2].email)//Output=>brajmohan@microsoft.com 
//Its Indexing always starts with 0 Index Number
console.log(Users[0].email)//Ouptput=>brajmohan@innovativeinfonet.in

console.log(tinder)

//Suppose we wnat to get the key and Value of the Objects the we can use

console.log(Object.keys(tinder));//Output=>['id', 'name', 'email', 'address'] it is return an Array
console.log(Object.values(tinder));//Output=>['123abc', 'Gaurav Sharma', 'gruravsharma@google.com', 'Aligarh'] it is also return an Array

//Suppose if we want to Store every key value pair into an Array then we can use entries

console.log(Object.entries(tinder));//Output=>[ ['id', '123abc'],['name', 'Gaurav Sharma'],['email', 'gruravsharma@google.com'],['address', 'Aligarh']]

//Suppose we want to check the value is exist in an Object or not...


console.log(tinder.hasOwnProperty('email'))//Output=>true
console.log(tinder.hasOwnProperty('isLoggedIn'))//Output=>False