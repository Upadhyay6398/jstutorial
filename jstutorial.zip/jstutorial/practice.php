<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JavaScript Practice</title>
</head>
<body>
<p>Call a function which performs a calculation and returns the result:</p>
    <p id="demo"></p>
    <script>
 
    </script>
</body>
</html>