<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Degital Clock</title>
</head>
<style>
.center {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f0f0f0;
    font-family: 'Arial', sans-serif;
}
#banner {
    background-color: #4CAF50;
    color: white;
    font-size: 24px;
    padding: 20px 40px;
    border-radius: 8px;
    text-align: center;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

#clock {
    font-size: 48px;
    color: #333;
    font-weight: bold;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #fff;
    border: 2px solid #4CAF50;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    display: inline-block;
}

#clock {
    transition: font-size 0.5s ease-in-out;
}

</style>
<body>

<div class="center">
    <div id="banner"><span>Your Local Time</span></div>
    <div id="clock"></div>
</div>
<script src="projects3.js"></script>
</body>
</html>