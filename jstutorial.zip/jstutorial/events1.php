<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Click Event Example</title>
</head>
<body>
  <button id="myButton">Click me!</button>
  <p id="message"></p>

<script>
    document.getElementById('myButton').addEventListener("click",function(){
        document.getElementById('message').innerHTML="This Button Was Clicked"
    })
</script>
</body>
</html>
