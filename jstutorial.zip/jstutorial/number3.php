<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Number of JavaScript</title>
</head>
<body>
    <h1>Number In JavaScript</h1>
    <script src="number.js" type="text/javascript"></script>
</body>
</html>