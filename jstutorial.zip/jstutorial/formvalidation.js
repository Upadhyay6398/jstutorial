function validateForm(event) {
    document.getElementById('nameError').innerHTML = "";
    document.getElementById('emailError').innerHTML = "";
    document.getElementById('phoneError').innerHTML = "";
    document.getElementById('messageError').innerHTML = "";

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById('email').value.trim();
    let phone = document.getElementById('phone').value.trim();
    let message = document.getElementById('message').value.trim();

    let valid = true;
    // Name Validation
    if (name === '') {
        document.getElementById("nameError").innerHTML = "Name is required.";
        valid = false;
    }

    // Email Validation
    let emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (email === '' || !emailPattern.test(email)) {
        document.getElementById('emailError').innerHTML = "Email is Required";
        valid = false;
    }

    if (phone === '' ||isNaN(phone)){
        document.getElementById('phoneError').innerHTML = "Phone Number is required";
        valid = false;
    }

    // Message Validation (Optional: Add minimum length for message)
    if (message === '') {
        document.getElementById('messageError').innerHTML = "Message is required.";
        valid = false;
    }

    // If validation fails, prevent form submission
    if (!valid) {
        event.preventDefault();
    }
}