<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Api of JavaScript</title>
</head>
<body>
    <h2>What is Api</h2>
    <p>Api Stands for Application Programming Interface Api are used to Intract with one machine to another machine api is just like a medium Suupose two persion are talk to each other then with the help of api we can intract with two machine</p>

    <h1>XML HTTP REQUEST</h1>
    <p>XMLHttpRequest (XHR) objects are used to interact with servers. You can retrieve data from a URL without having to do a full page refresh. This enables a Web page to update just part of a page without disrupting what the user is doing.</p>
    
</body>
<script>
    const requestUrl='https://api.github.com/users/hiteshchoudhary'
    const xhr=  new XMLHttpRequest()
    xhr.open('GET',requestUrl)//IN the Open value is always 1 its value can not be change if we want to change the value continuously then
    xhr.onreadystatechange=function()
    {
        console.log(xhr.readyState)
        if(xhr.readyState===4)
    {
        // const data= this.responseText;
        // console.log(typeof data)//Jb bhi url se response aata h to vo string me hi aata h

        const data=JSON.parse(this.responseText)
        console.log(typeof data)

        console.log(data.followers)
    }
    }
    xhr.send();
</script>
</html>