//Add to Cart

function calculateCartPrice(...num1)
{
    return num1
}
console.log((calculateCartPrice(100,200,175,2000)))

//How to Handle Object With Function...

const user={
    name:"Braj Mohan Upadhyay",
    age:23
}
function handelObject(anyObject)
{
    console.log(`${anyObject.name} your age is ${anyObject.age}`)
}
handelObject(user)


