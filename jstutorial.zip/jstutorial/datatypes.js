"use strict"//treat all js code as newer version or newer js
let name="Hitesh" //String Datatype
let age=18//Number Datatype
let isLoggedIn=true//Boolean Datatype


//There are different type of DataType in JavaScript

//number =>range of Number is 2 to Power 53
//bigInt=>It is used if Number is to large like stock market
//string =>String is written in double quote or single quote
//Bollean =True/False
//null=>Standalone Value
//undefined=>Value is not Defined
//Symbol=>Symbol are used to find the Uninqueness

console.log(NaN===NaN)//Ouput=>false
console.log(2===2)//Ouput=>True
console.log(Number.isNaN(NaN))//Output=>true
console.log(typeof NaN)//Output=>Number
console.log(typeof null)//Ouput=>Object
console.log(typeof undefined)//Output=>Undefined

//Note console.log(NaN===NaN)//Ouput=>false Provide the false result that's why Nan is not equal to Anything including itself So when you compare NaN === NaN, it results in false


//Here's a quick explanation:

//2 === 2 outputs true because both sides are the same value.
//NaN === NaN outputs false because, as per the JavaScript specification, NaN is not considered equal to any value, not even to itself.
