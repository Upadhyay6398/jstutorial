<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events In JavaScript</title>
</head>
<body style="background-color: #414141; color: #FFFF;">
    <h2>Amezing Images</h2>
    <div>
    <ul id="image">
        <li><img src="images/10020.jpg" width="200px" id="image1"></li>
        <!-- <li><img src="images/10025.jpg" width="200px" id="image2" onclick="alert('This is an India Image ')"></li> -->
        <!--Here in the Second li emelent we apply onclick event then it show an alert like This is an India Image but It is not an feasable approach -->
         <li><img src="images/10025.jpg" width="200px" id="image2" onclick="alert('This is an India Image ')"></li>
        <li><img src="images/do-dham-yatra-mbo-banner.jpg" width="200px" id="image3"></li>
    </ul>
    </div>
    <script src="event.js"></script>
</body>
</html>