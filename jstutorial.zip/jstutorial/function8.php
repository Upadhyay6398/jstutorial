<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Function in JavaScript</title>
</head>
<body>
<h3>Function in JavaScript</h3>
<script src="function.js" type="text/javascript"></script>
<script src="function2.js" type="text/javascript"></script>
</body>
</html>