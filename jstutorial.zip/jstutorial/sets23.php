<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>In JavaScript, a Set is a collection of unique values, meaning it stores only distinct elements. It can store values of any type, whether primitive values or object references..</p>

<script src="sets.js"></script>
</body>
</html>