<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reduce in JavaScript</title>
</head>
<body>
<h3>Reduce In JavaScript</h3>
<script src="reduce.js" type="text/JavaScript"></script>
</body>
</html>