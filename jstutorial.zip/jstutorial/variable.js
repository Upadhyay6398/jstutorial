
const accountId=14231
let accountName="Braj Mohan Upadhyay"
var accountEmail="defencelover6398@gmail.com"
accountCity="Aligarh"
//accountId=5;//Not allowed Const can not be redclear and updated
accountName="Neetesh Sharma"
accountEmail="braj@google.com"
console.table([accountId,accountName,accountEmail,accountCity]);