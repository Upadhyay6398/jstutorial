//Reduce In JavaScript....

//Reduce are used suppose you have an e commerce website and user is buy item and it is add some item in to the Add to cart for calculate the total amount we use reducte

const numsArray=[5,12,14,9,7,1]

const totalNums=numsArray.reduce(function(acc,currentValue){

    console.log(`acc:${acc} and Current value ${currentValue}`)
    return acc+currentValue
}, 0)
console.log("Total =",totalNums)

//Output=>acc:0 and Current value 5
// acc:5 and Current value 12
// acc:17 and Current value 14
// acc:31 and Current value 9
// acc:40 and Current value 7
// acc:47 and Current value 1
//Total = 48



const numsArray1=[5,12,14,9,7,1]

const totalNums1=numsArray1.reduce(function(acc1,currentValue1){

    console.log(`acc:${acc1} and Current value ${currentValue1}`)
    return acc1+currentValue1
}, 5)
console.log("Total =",totalNums1)

//Output=>acc:5 and Current value 5
//acc:10 and Current value 12
//acc:22 and Current value 14
//acc:36 and Current value 9
//acc:45 and Current value 7
//acc:52 and Current value 1
//Total = 53

//Note the acc value is set by the user like in the first example we set the acc value is 0 and it will we start  to the 0 and in the second example we set the acc value is 5 then it will start to the 5...


//Reduce Using Arraow Function....

const myTotal=numsArray.reduce( (acc2,currentValue) => acc2+currentValue,0)
//console.log(`ACC Value is : ${acc2} and Current value is ${currentValue}`)
console.log(myTotal)


const newArray=[17,12,16,19,89,11,55]

const anotherNewArray=newArray.reduce(function(acc1,acc2){

    console.log(`Acc Value is ${acc1} and the Current Value is ${acc2}`)
    return acc1+acc2

},0)
console.log("Total:-",anotherNewArray)