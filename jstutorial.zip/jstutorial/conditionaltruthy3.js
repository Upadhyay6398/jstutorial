const email="hitesh@google.com"
if(email)
{
    console.log("Got User Email")
}
else{
    console.log("Don't Got User Email")
}

//Falsy Values
//1.False
//2.0
//3.-0
//4.BigInt 0nd
//5."" this is empty string
//6.null
//7.Undefined
//8.Nan


//Truthy Values
//1."0"
//2."False"
//3." "
//4.[]
//5.{}
//6.function()

//How to Check Array is Empty or Not...

const Array1=[]
if(Array1.length===0)
{
    console.log("Array is Empty");//Output=>Array is Empty
}
else{
    console.log("Array is not Empty");
}

//How to Check Empty Object...

const object1={}

if(Object.keys(object1).length===0)
{
    console.log("Our Object is Empty")//Ouput=>Our Object is Empty
}
else{
    console.log("Out Object is not an Empty")
}

//Some Important Rules

//if(false==0) Output=>True
//if(false=="0") output=>True
//if(0=="") Ouput=>True


//Nullish Colescing Operator (??) : null Undefined

//NUllish COlescing Operator jo h vo saftery check krta h ki value null na ho kyoki kuch program job h vo null ke base pr execute nahi hote h

let val1;
val1=10 ?? 5
console.log(val1)//Ouput=>10

let val2;
val2=null ?? 5
console.log(val2)//Output=>5

let val3;
val3=undefined ?? 15
console.log(val3)//Output=>15

//Note:- Null Collesion Operator jo h vo keval Null or Undefined ke liye hi bana h

//Suppose in a Program has Number of Nullish Colescing Operator then jo bhi first value milegi usi ko null assign ho jata h...

let val4;
val4=null??10??15??undefined
console.log(val4)//Ouput=>10

//Terniary Operator...

//Condition ? True : False...

const iceTeaPrice=100
iceTeaPrice>=80 ? console.log("Ice Tea Price is Greater then 80") :console.log("Ice Tea Price is Less then 100")
