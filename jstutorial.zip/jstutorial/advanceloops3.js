
//Foreach Loops in JavaScript.....

const coding=["Html","Css","Javascript","Php","Bootstrap","Wordpress","Magento"]

coding.forEach(function (val1)
{
// console.log(val1)
})
//Output=>Html
//Css
//Javascript
//Php
//Bootstrap
//Wordpress
//Magento

//Foreach Loop With Arrow Functions

coding.forEach((item)=>{
    // console.log(item)
})
//Output=>Html
//Css
//Javascript
//Php
//Bootstrap
//Wordpress
//Magento

//Another way if we define function already and we want ot use it 

function printMe(item)
{
    console.log(item)
}
coding.forEach(printMe)

//Output=>Html
//Css
//Javascript
//Php
//Bootstrap
//Wordpress
//Magento

//Arrow function are not hold only one value it is hold some more value like item indexNumber or complete array
//Example

coding.forEach((item,index,arr)=>{
    console.log(item,index,arr)
})

//Output=>
// Html 0 (7) ['Html', 'Css', 'Javascript', 'Php', 'Bootstrap', 'Wordpress', 'Magento']
// Css 1 (7) ['Html', 'Css', 'Javascript', 'Php', 'Bootstrap', 'Wordpress', 'Magento']
// Javascript 2 (7) ['Html', 'Css', 'Javascript', 'Php', 'Bootstrap', 'Wordpress', 'Magento']
// Php 3 (7) ['Html', 'Css', 'Javascript', 'Php', 'Bootstrap', 'Wordpress', 'Magento']
// 51 Bootstrap 4 (7) ['Html', 'Css', 'Javascript', 'Php', 'Bootstrap', 'Wordpress', 'Magento']
// 51 Wordpress 5 (7) ['Html', 'Css', 'Javascript', 'Php', 'Bootstrap', 'Wordpress', 'Magento']
// 51 Magento 6 (7) ['Html', 'Css', 'Javascript', 'Php', 'Bootstrap', 'Wordpress', 'Magento']


const myCoading=[
    {
        languageName:"JavaScript",
        languageFileName:"js"
    },
    {
        languageName:"Java",
        languageFileName:"java"
    },
    {
        languageName:"Python",
        languageFileName:"py"
    },
]
myCoading.forEach((item)=>{

    console.log(item.languageName)
})
//Output=>JavaScript
// Java
// Python