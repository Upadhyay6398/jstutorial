<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How to Create New Dom Element</title>
</head>
<body style="background-color:#212121; color:#fff">
    <div class="parent">
        <!--Dom Manipulation in JavaScript-->
        
    <div class="day">Monday</div>
    <div class="day">Tuesday</div>
    <div class="day">Wednesday</div>
    <div class="day">Thursday</div>
    </div>
    <script src="createnewdomelement.js"></script>
</body>
</html>