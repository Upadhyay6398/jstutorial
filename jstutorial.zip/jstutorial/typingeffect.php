<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Typing Effect</title>
    <link rel="stylesheet" href="styles.css">
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    background-color:#212121;
}

.container {
    text-align: center;
}

#typing-text {
    font-size: 2em;
    color: #333;
    display: inline-block;
    border-right: 4px solid #333; 
    padding-right: 10px;
    white-space: nowrap;
    overflow: hidden;
}

</style>
<body>
    <div class="container">
        <h1 id="typing-text"></h1>
    </div>

    <script>
        const text="Welcome to My Website"
        let index=0;
        const typingElement=document.getElementById('typing-text')
        typingElement.style.color="White"

        function typeText()
        {
            if(index<text.length)
            {
                typingElement.innerHTML+=text.charAt(index);
                index++;
                setTimeout(typeText,500)
            }
        }
        typeText();
    </script>

</body>
</html>
