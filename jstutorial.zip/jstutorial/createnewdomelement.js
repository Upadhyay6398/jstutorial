//How to Create New Dom Element...
const parent=document.querySelector('.parent')
console.log(parent) //Output=><div class="parent">
//<div class="day">Monday</div>
//<div class="day">Tuesday</div>
//<div class="day">Wednesday</div>
//<div class="day">Thursday</div>
//</div>
console.log(parent.children)//It is get the Html Node List
console.log(parent.children[1])//Output=><div class="day">Tuesday</div> because Array indexing is start wiht 0 so the first value is Tuesday
console.log(parent.children[1].innerHTML)//Output=>Tuesday
console.log(parent.children[2].innerHTML="Friday")//Output=>Friday

for(i=0;i<parent.children.length;i++)
{
    console.log(parent.children[i].innerHTML)
}
//Output=>Monday
//Tuesday
//Friday
//Thursday

console.log(parent.children[1].style.color="orange")//Change Color of Tuesday Orange

console.log(parent.firstElementChild)//Output=><div class="day">Monday</div>

console.log(parent.lastElementChild)//Output=><div class="day">Thursday</div>


//Note:- In the Previous Step I m move from Parent to child but now i want to move from child to parent

const childNode=document.querySelector('.day')
console.log(childNode)//Output=><div class="day">Monday</div>

console.log(childNode.parentElement)//Output=><div class="parent">
//<div class="day">Monday</div>
//<div class="day">Tuesday</div>
//<div class="day">Wednesday</div>
//<div class="day">Thursday</div>
//</div>

console.log(childNode.nextElementSibling)//Output=><div class="day" style="color:orange">Tuesday</div>

console.log("NODES:-",parent.childNodes)
