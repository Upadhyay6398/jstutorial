<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mouseover Event Example</title>
</head>
<body>
  <button id="hoverDiv" style="width: 200px; height: 50px; background-color: #212121;color: #FFFF;">
    Hover over me!
  </button>
  <p id="message"></p>

  <script>
    document.getElementById("hoverDiv").addEventListener("mouseover", function() {
      document.getElementById("message").textContent = "Mouse is over the div!";
    });
  </script>
</body>
</html>
