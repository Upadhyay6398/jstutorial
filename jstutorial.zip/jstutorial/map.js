const myNumber=[1,2,3,4,5,6,7,8,9,10]

const newNums=myNumber.map((num)=>num+10)
console.log(newNums)//Output=>[11, 12, 13, 14, 15, 16, 17, 18, 19,20]

//The map() method does not modify the original array. It returns a new array with the transformed values.
const map1=new Map()
map1.set('IN','INDIA')
map1.set('USA','UNITED STATES OF AMERICA')
map1.set('UAE','UNITED ARAB EMERAT')
map1.set('FRI','FRANCE')
map1.set('BAN','BANGLADES')

console.log(map1)
map1.forEach((value, key) => {
    console.log(key);
});
