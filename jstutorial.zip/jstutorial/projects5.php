<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guess The Random Number</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
            overflow: hidden;
        }

        .game-container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 450px;
            animation: fadeIn 0.6s ease-in-out;
        }

        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(-20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        h1 {
            font-size: 30px;
            margin-bottom: 20px;
            font-weight: 700;
            color: #4b3b64;
        }

        p {
            font-size: 18px;
            margin-bottom: 20px;
            color: #555;
            font-weight: 300;
        }

        .input-area {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        input {
            padding: 15px;
            font-size: 18px;
            width: 70%;
            border: 2px solid #ddd;
            border-radius: 8px;
            outline: none;
            margin-right: 10px;
            transition: border-color 0.3s ease;
        }

        input:focus {
            border-color: #a18cd1;
        }

        button {
            padding: 15px 25px;
            font-size: 16px;
            border: none;
            background-color: #ff6f61;
            color: white;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color: #ff3f2b;
            transform: scale(1.1);
        }

        .result p {
            font-size: 20px;
            font-weight: 500;
            margin-top: 20px;
        }

        .attempts {
            font-size: 18px;
            margin-top: 10px;
            color: #777;
        }

        #restart {
            background-color: #4CAF50;
            padding: 15px 25px;
            font-size: 16px;
            border-radius: 8px;
            color: white;
            margin-top: 20px;
            cursor: pointer;
            display: none;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        #restart:hover {
            background-color: #45a049;
            transform: scale(1.1);
        }

        @media (max-width: 500px) {
            .game-container {
                width: 80%;
                padding: 30px;
            }

            input {
                width: 60%;
            }

            button {
                width: 30%;
            }
        }
    </style>
</head>
<body>
    <div class="game-container">
        <h1>Guess the Number Game</h1>
        <p>Guess a number between 1 and 100</p>
        <form>
        <div class="input-area">
            <input type="text" id="guess" placeholder="Enter your guess" min="1" max="100" />
            <button type="submit" id="submit">Submit Guess</button>
        </div>
        </form>
        <div class="result">
            <p id="message"></p>
        </div>

        <div class="attempts">
            <p>Previous Guess: <span id="previousGuess" class="previousGuess">0</span></p>
        </div>
        <div class="attempts">
            <p>Attempts Remaining: <span id="totalAttempt" class="totalAttempt">0</span></p>
        </div>
        <button id="restart" class="restart">Play Again</button>
    </div>
    <script src="project5.js" type="text/javascript"></script>
</body>
</html>
